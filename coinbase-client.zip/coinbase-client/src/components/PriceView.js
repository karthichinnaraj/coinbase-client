import React from "react";

function PriceView({ priceData, subscribedProducts }) {
  return (
    <div>
      <h3>Price View</h3>
      {subscribedProducts.map((product) => (
        <div key={product}>
          <h4>{product}</h4>
          <p>Bids: {priceData[product]?.bids}</p>
          <p>Asks: {priceData[product]?.asks}</p>
        </div>
      ))}
    </div>
  );
}

export default PriceView;
