import React from "react";

function Subscribe({ subscribeProduct, unsubscribeProduct, subscribedProducts }) {
  const products = ["BTC-USD", "ETH-USD", "XRP-USD", "LTC-USD"];

  return (
    <div>
      {products.map((product) => (
        <div key={product}>
          <span>{product}</span>
          <button
            onClick={() => subscribeProduct(product)}
            disabled={subscribedProducts.includes(product)}
          >
            Subscribe
          </button>
          <button
            onClick={() => unsubscribeProduct(product)}
            disabled={!subscribedProducts.includes(product)}
          >
            Unsubscribe
          </button>
        </div>
      ))}
    </div>
  );
}

export default Subscribe;
