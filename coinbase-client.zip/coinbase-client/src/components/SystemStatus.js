import React from "react";

function SystemStatus({ subscribedProducts }) {
  return (
    <div>
      <h3>System Status</h3>
      <ul>
        {subscribedProducts.map((product) => (
          <li key={product}>{product}</li>
        ))}
      </ul>
    </div>
  );
}

export default SystemStatus;
