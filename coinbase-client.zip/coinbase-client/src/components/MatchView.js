import React from "react";

function MatchView({ matchData }) {
  return (
    <div>
      <h3>Match View</h3>
      {matchData.map((match, index) => (
        <div key={index} style={{ color: match.side === "buy" ? "green" : "red" }}>
          {match.time} - {match.product_id} - Size: {match.size} - Price: {match.price}
        </div>
      ))}
    </div>
  );
}

export default MatchView;
