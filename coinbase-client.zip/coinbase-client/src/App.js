import React, { useState, useEffect } from "react";
import Subscribe from "./components/Subscribe";
import PriceView from "./components/PriceView";
import MatchView from "./components/MatchView";

function App() {
  const [subscribedProducts, setSubscribedProducts] = useState([]);
  const [priceData, setPriceData] = useState({});
  const [matchData, setMatchData] = useState([]);
  const [ws, setWs] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState("Connecting...");

  useEffect(() => {
    // Initialize WebSocket and handle its lifecycle
    const newWs = new WebSocket("ws://localhost:3001");

    newWs.onopen = () => {
      console.log("WebSocket connection established");
      setConnectionStatus("Connected");
      setWs(newWs);
    };

    newWs.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === "l2update") {
        setPriceData((prevData) => ({ ...prevData, [data.product_id]: data }));
      } else if (data.type === "match") {
        setMatchData((prevData) => [data, ...prevData.slice(0, 20)]);
      }
    };

    newWs.onerror = (error) => {
      console.error("WebSocket error:", error);
      setConnectionStatus("Error: Could not connect");
    };

    newWs.onclose = () => {
      console.log("WebSocket connection closed");
      setConnectionStatus("Disconnected");
      // Optionally retry connection here
    };

    return () => {
      // Cleanup the WebSocket connection on component unmount
      if (newWs) {
        newWs.close();
      }
    };
  }, []);

  const subscribeProduct = (product) => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: "subscribe", product_id: product }));
      setSubscribedProducts((prev) => [...prev, product]);
    } else {
      console.error("WebSocket is not initialized yet or not open");
    }
  };

  const unsubscribeProduct = (product) => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: "unsubscribe", product_id: product }));
      setSubscribedProducts((prev) => prev.filter((p) => p !== product));
    } else {
      console.error("WebSocket is not initialized yet or not open");
    }
  };

  return (
    <div>
      <p>Status: {connectionStatus}</p>
      <Subscribe
        subscribeProduct={subscribeProduct}
        unsubscribeProduct={unsubscribeProduct}
        subscribedProducts={subscribedProducts}
      />
      <PriceView priceData={priceData} subscribedProducts={subscribedProducts} />
      <MatchView matchData={matchData} />
    </div>
  );
}

export default App;
